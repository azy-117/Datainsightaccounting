I'll create a modern, professional landing page with a dark theme that emphasizes your accounting expertise and value proposition.

<ant_thinking>Creating a new React landing page with a dark theme and professional design. This will be a new artifact with clear sections and strong visual hierarchy.</ant_thinking>

<ant_artifact identifier="accounting-landing" type="application/vnd.ant.react" title="Dark Theme Accounting Landing Page">
import React from 'react';
import { ArrowRight, CheckCircle, Clock, Search, TrendingUp } from 'lucide-react';

export default function AccountingLanding() {
  return (
    <div className="min-h-screen bg-black text-white font-inter">
      {/* Hero Section */}
      <div className="max-w-6xl mx-auto px-4 py-16">
        <h1 className="text-4xl md:text-5xl font-bold text-center mb-6 bg-gradient-to-r from-blue-500 to-purple-500 bg-clip-text text-transparent">
          The Accounting System That Works
        </h1>
        <p className="text-xl text-center text-gray-300 mb-8">
          5 Years of Research to Simplify Your Finances and Free You from Daily Tasks
        </p>

        {/* Key Features Grid */}
        <div className="grid md:grid-cols-3 gap-8 mb-16">
          <div className="bg-gray-900 p-6 rounded-xl">
            <h3 className="text-xl font-semibold mb-3">Big 4 Accounting Expertise</h3>
            <p className="text-gray-400">Professional expertise from industry leaders</p>
          </div>
          <div className="bg-gray-900 p-6 rounded-xl">
            <h3 className="text-xl font-semibold mb-3">Big 3 Data Analytics</h3>
            <p className="text-gray-400">Your Unfair Business Advantage</p>
          </div>
          <div className="bg-gray-900 p-6 rounded-xl">
            <h3 className="text-xl font-semibold mb-3">Guaranteed Results</h3>
            <p className="text-gray-400">Punctual Reports or 100% Money Back</p>
          </div>
        </div>

        {/* Stats Section */}
        <div className="bg-gradient-to-r from-blue-900/50 to-purple-900/50 rounded-2xl p-8 mb-16">
          <div className="grid md:grid-cols-2 gap-8">
            <div>
              <h2 className="text-3xl font-bold mb-6">Your Transformation Starts Now</h2>
              <div className="flex items-center gap-2 mb-4">
                <Clock className="text-blue-400" />
                <span>10/30 Businesses Already Onboarded</span>
              </div>
              <div className="flex items-center gap-2 mb-4">
                <TrendingUp className="text-blue-400" />
                <span>1,000 AED/Month Unlimited Reconciliation</span>
              </div>
              <div className="flex items-center gap-2">
                <Search className="text-blue-400" />
                <span>Insights from 1,000+ Business Analyses</span>
              </div>
            </div>
            
            {/* Free Score Section */}
            <div className="bg-gray-900 p-6 rounded-xl">
              <h3 className="text-2xl font-bold mb-4">FREE Business Accounting Health Score</h3>
              <ul className="space-y-3 mb-6">
                <li className="flex items-center gap-2">
                  <CheckCircle className="text-green-400" size={20} />
                  <span>Personalized diagnostic based on 5 years of research</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="text-green-400" size={20} />
                  <span>Reveals hidden financial blind spots</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="text-green-400" size={20} />
                  <span>Identifies immediate growth opportunities</span>
                </li>
              </ul>
              <button className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-6 rounded-lg transition-colors flex items-center justify-center gap-2">
                GET MY FREE ACCOUNTING SCORE NOW
                <ArrowRight size={20} />
              </button>
            </div>
          </div>
        </div>

        {/* Reconciliation Feature */}
        <div className="bg-gray-900 p-8 rounded-xl text-center">
          <h2 className="text-2xl font-bold mb-4">Unlimited Reconciliation</h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
            Say goodbye to hours of manual work. Our system offers unlimited reconciliation, 
            helping you maintain accurate, up-to-date records with ease.
          </p>
        </div>
      </div>
    </div>
  );
}
</ant_artifact>

I've created a professional landing page with:
- Dark theme with gradient accents
- Clear hierarchy and sections
- Modern UI components
- Responsive design
- Interactive elements
- Professional icons from Lucide
- Emphasis on key benefits and features

Would you like me to adjust any specific aspects of the design?